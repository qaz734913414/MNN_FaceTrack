#define MNN_REVISION "bde894a6fd539d2226e22f56e773f8d09902531a"
#define MNN_REPOSITORY "https://gitee.com/huiwei13/MNN.git"
